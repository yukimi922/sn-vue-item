module.exports = {
    getGoodsById(pid){
        let a = [
            {
                pid:0,
                shopName:'百草味官方旗舰店',
                title:'百草味 蜜饯 玫瑰红葡萄干200g 新疆特产小吃零食果脯红提子干任选',
                price:18,
                pr2: 9,
                img:'./images/DZO9UnS1duyD68X-eRd3-A.jpg',
                img2:'./images/DZO9UnS1duyD68X-eRd3-A.jpg',
                sale:'拼购'
            },
            {
                pid:1,
                shopName:'来伊份官方旗舰店',
                title:'专区 来伊份榴莲干30g金枕头榴莲干冻干水果干蜜饯休闲零小吃来一份',
                price:39,
                pr2: 9,
                img:'./images/Rfv2WA1TV7aeNSeHnIFa4Q.jpg',
                img2:'./images/Rfv2WA1TV7aeNSeHnIFa4Q.jpg',
                sale:'领劵减50'
            },
            {
                pid:2,
                shopName:'良品铺子官方旗舰店',
                title:'良品铺子 每日坚果 综合果仁 750gx1箱装 坚果 零食礼包 零食30包原味混合坚果礼盒 零食大礼包',
                price:89,
                img:'./images/iT1Bu4EvdP7tleQX1Y88Cw.jpg',
                img2:'./images/iT1Bu4EvdP7tleQX1Y88Cw.jpg',
                sale:'99元6件',
                sale2:'领劵20-4'
            },
            {
                pid:3,
                shopName:'三只松鼠官方旗舰店',
                title:'【三只松鼠_夏威夷果160g】休闲零食每日坚果特产炒货干果奶油味送开口器',
                price:39,
                pr2: 9,
                img:'./images/JiYY8X3Hyh8FmogvWH_F8w.jpg',
                img2:'./images/JiYY8X3Hyh8FmogvWH_F8w.jpg',
                sale:'大惠聚'
            }
        ]
        let b = a[pid];
        return b;
    }
}