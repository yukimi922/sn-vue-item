module.exports={
    getGoodsItem(){
        let a = {
            products:[
                {
                    pid:0,
                    shopName:'百草味官方旗舰店',
                    title:'百草味 蜜饯 玫瑰红葡萄干200g 新疆特产小吃零食果脯红提子干任选',
                    price:18,
                    pr2: 90,
                    img:'./images/QosokJAEs-Y95r0uJ__V4A.png',
                },
                {
                    pid:1,
                    shopName:'百草味官方旗舰店',
                    title:'百草味 蜜饯 玫瑰红葡萄干200g 新疆特产小吃零食果脯红提子干任选',
                    price:18,
                    pr2: 90,
                    img:'./images/QosokJAEs-Y95r0uJ__V4A.png',
                },
                {
                    pid:2,
                    shopName:'百草味官方旗舰店',
                    title:'百草味 蜜饯 玫瑰红葡萄干200g 新疆特产小吃零食果脯红提子干任选',
                    price:18,
                    pr2: 90,
                    img:'./images/QosokJAEs-Y95r0uJ__V4A.png',
                },
                {
                    pid:3,
                    shopName:'百草味官方旗舰店',
                    title:'百草味 蜜饯 玫瑰红葡萄干200g 新疆特产小吃零食果脯红提子干任选',
                    price:18,
                    pr2: 90,
                    img:'./images/QosokJAEs-Y95r0uJ__V4A.png',
                }
            ]
        }
        return a
    }
}